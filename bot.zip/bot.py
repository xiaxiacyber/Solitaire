import json
import time
import random
import urllib.parse
import aiohttp
import aiosqlite
import discord
from discord import app_commands
from discord.ui import Select, View, Modal, Button, TextInput

EMBED_COLOR = 0x3d0108
MAIN_CHANNEL_ID = 1449747812941172875
APPLICATIONS_CHANNEL_ID = 1537568853578620939
STAFF_CHAT_ID = 1449747813675171888

ACCEPT_IMAGE = "https://img.freepik.com/free-psd/check-mark-icon-green-bubble-symbol-element-3d-illustration_56104-2730.jpg?semt=ais_hybrid&w=740"
REJECT_IMAGE = "https://e7.pngegg.com/pngimages/723/887/png-clipart-computer-icons-x-mark-check-mark-red-x-miscellaneous-text-thumbnail.png"
LOGO_IMAGE = "https://i.imgur.com/J5h6W7v.png"

ROLE_IDS = {
    "Moderator": 1449747812354097192,
    "Editor": 1449747812299575459,
    "Coach": 1537524657962618900,
    "Support": 1537529643165556766,
}

MAIN_EMBED_DESCRIPTION = """
## Набор на роль Staff

> **Требования:**
> - Уделять серверу не менее часа в день.
> - Быть не младше 14 лет.
> - Адекватность и стрессоустойчивость.
> - Знать правила сервера.

> **Что вы получите:**
> - Еженедельная зарплата в виде серверной валюты.
> - Интересное времяпровождения.
> - Отзывчивую администрацию.
> - Дружелюбный коллектив.

-# Ждём Вас в нашей дружной семье!
"""

QUESTIONS = {
    "Moderator": [
        ("Как вас зовут? Сколько вам лет?", "Максим, 20"),
        ("Опыт модерации?", "1 год на другом сервере"),
        ("Как будете реагировать на нарушения?", "По правилам сервера"),
        ("Знание правил сервера (1-10)?", "8"),
        ("Доступное время?", "4 часа в день"),
    ],
    "Editor": [
        ("Как вас зовут? Сколько вам лет?", "Анна, 19"),
        ("Ваш рейтинг и игровой опыт?", "1800 Blitz, играю 3 года"),
        ("Почему хотите стать редактором?", "Хочу помогать с контентом"),
        ("Умеете работать с текстом?", "Да, пишу и редактирую посты"),
        ("Где ищете шахматные новости?", "Chess.com, Lichess, Telegram"),
    ],
    "Coach": [
        ("Как вас зовут? Сколько вам лет?", "Максим, 20"),
        ("Ваш рейтинг и опыт игры?", "2100 Rapid, играю 5 лет"),
        ("Есть опыт обучения игроков?", "Да, помогал новичкам"),
        ("Что готовы преподавать?", "Дебюты, тактика, эндшпиль"),
        ("Готовы проводить занятия?", "Да, раз в неделю"),
    ],
    "Support": [
        ("Как вас зовут? Сколько вам лет?", "Ольга, 18"),
        ("Есть ли микрофон?", "Да"),
        ("Опыт работы в поддержке?", "Помогал на другом сервере"),
        ("Как решаете сложные вопросы?", "По инструкции"),
        ("Часовой пояс и график?", "МСК+3, вечером"),
    ],
}


HEADERS = {
    "User-Agent": "QwettLichessBot/1.0 (Discord Integration)",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
}

verification_codes: dict[int, dict] = {}
puzzle_cooldowns: dict[int, float] = {}


async def get_user_row(discord_id: int):
    async with aiosqlite.connect("lichess_bot.db") as db:
        async with db.execute(
            "SELECT lichess_username, puzzles_solved FROM users WHERE discord_id = ?",
            (discord_id,),
        ) as cursor:
            return await cursor.fetchone()


async def get_active_puzzle(discord_id: int):
    async with aiosqlite.connect("lichess_bot.db") as db:
        async with db.execute(
            "SELECT puzzle_id FROM active_puzzles WHERE discord_id = ?",
            (discord_id,),
        ) as cursor:
            return await cursor.fetchone()


async def fetch_json(session: aiohttp.ClientSession, url: str, timeout: float = 6.0):
    try:
        async with session.get(
            url,
            headers=HEADERS,
            timeout=aiohttp.ClientTimeout(total=timeout),
        ) as resp:
            if resp.status == 200:
                return await resp.json()
    except Exception as e:
        print(f"[API Error] {url} → {e}")
    return None


async def fetch_random_puzzle(session: aiohttp.ClientSession) -> tuple[str, str] | None:
    next_data = await fetch_json(session, "https://lichess.org/api/puzzle/next")
    if not next_data:
        return None

    puzzle_id = next_data.get("puzzle", {}).get("id")
    if not puzzle_id:
        return None

    full = await fetch_json(
        session,
        f"https://lichess.org/api/puzzle/{puzzle_id}?_t={int(time.time() * 1000)}",
    )
    if not full:
        return None

    fen = full.get("puzzle", {}).get("fen")
    if not fen:
        fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    return puzzle_id, fen


class PuzzleView(discord.ui.View):
    def __init__(self, puzzle_url: str):
        super().__init__(timeout=None)
        self.add_item(
            discord.ui.Button(
                label="♟️ Решить на Lichess",
                url=puzzle_url,
                style=discord.ButtonStyle.link,
            )
        )

    @discord.ui.button(
        label="✅ Засчитать задачу",
        style=discord.ButtonStyle.green,
        custom_id="solve_puzzle_btn",
    )
    async def solved_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        user_id = interaction.user.id

        now = time.time()
        last_try = puzzle_cooldowns.get(user_id, 0)
        if now - last_try < 10:
            return await interaction.followup.send(
                f"⏳ Подожди ещё {10 - int(now - last_try)} сек. перед повторной попыткой.",
                ephemeral=True,
            )
        puzzle_cooldowns[user_id] = now

        user_row = await get_user_row(user_id)
        if not user_row:
            return await interaction.followup.send(
                "❌ Сначала привяжи аккаунт Lichess через `/link <username>`!",
                ephemeral=True,
            )

        puzzle_row = await get_active_puzzle(user_id)
        if not puzzle_row:
            return await interaction.followup.send(
                "❌ У тебя нет активной задачи! Получи новую через `/puzzle`.",
                ephemeral=True,
            )

        target_puzzle_id = str(puzzle_row[0]).strip()

        async with aiosqlite.connect("lichess_bot.db") as db:
            await db.execute(
                "UPDATE users SET puzzles_solved = puzzles_solved + 1 WHERE discord_id = ?",
                (user_id,),
            )
            await db.execute(
                "DELETE FROM active_puzzles WHERE discord_id = ?",
                (user_id,),
            )
            await db.commit()

        await interaction.followup.send(
            f"🎉 **Отлично!** Задача #{target_puzzle_id} успешно засчитана! +1 в вашу статистику.",
            ephemeral=True,
        )

    @discord.ui.button(
        label="🔄 Новая задача",
        style=discord.ButtonStyle.blurple,
        custom_id="new_puzzle_btn",
    )
    async def new_puzzle_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await puzzle_cmd_logic(interaction)

class ApplicationView(View):
    def __init__(self, user_id: int):
        super().__init__(timeout=180)
        self.user_id = user_id

    @discord.ui.button(label="Принять", style=discord.ButtonStyle.green)
    async def accept(self, interaction: discord.Interaction, button: Button):
        try:
            await interaction.response.defer(ephemeral=True)
            role_name = interaction.message.embeds[0].title.split(": ")[1]

            user_embed = discord.Embed(
                title="🎉 Заявка одобрена!",
                description=f"Поздравляем! Вы приняты на роль **{role_name}**",
                color=0x00ff00,
            )
            user_embed.add_field(
                name="Добро пожаловать в команду!",
                value="Теперь у вас есть доступ к закрытым каналам сервера.",
                inline=False,
            )
            user_embed.set_thumbnail(url=ACCEPT_IMAGE)
            user_embed.set_footer(text="Спасибо за вашу активность!", icon_url=LOGO_IMAGE)

            staff_embed = discord.Embed(
                title="Новый участник команды",
                description=f"{interaction.user.mention} присоединился как {role_name}",
                color=0x00ff00,
            )
            staff_embed.set_thumbnail(url=interaction.user.display_avatar.url)

            member = await interaction.guild.fetch_member(self.user_id)
            role = interaction.guild.get_role(ROLE_IDS[role_name])
            if role:
                await member.add_roles(role)

            try:
                await member.send(embed=user_embed)
            except discord.Forbidden:
                print(f"Не удалось отправить ЛС пользователю {member}")

            staff_channel = interaction.guild.get_channel(STAFF_CHAT_ID)
            if staff_channel:
                await staff_channel.send(embed=staff_embed)

            await interaction.message.delete()
            await interaction.followup.send(
                f"Заявка принята! Роль {role_name} выдана.", ephemeral=True
            )
        except Exception as e:
            print(f"Ошибка при принятии: {e}")

    @discord.ui.button(label="Отклонить", style=discord.ButtonStyle.red)
    async def reject(self, interaction: discord.Interaction, button: Button):
        try:
            modal = RejectModal(self.user_id)
            await interaction.response.send_modal(modal)
        except Exception as e:
            print(f"Ошибка: {e}")


class RejectModal(Modal):
    def __init__(self, user_id: int):
        super().__init__(title="Причина отказа", timeout=300)
        self.user_id = user_id
        self.reason = TextInput(
            label="Укажите причину отказа",
            style=discord.TextStyle.long,
            required=True,
        )
        self.add_item(self.reason)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            member = await interaction.guild.fetch_member(self.user_id)

            embed = discord.Embed(
                title="😕 Заявка отклонена",
                description="К сожалению, ваша заявка не была одобрена.",
                color=0xff0000,
            )
            embed.add_field(name="Причина:", value=self.reason.value, inline=False)
            embed.add_field(
                name="Рекомендации:",
                value="Вы можете подать заявку снова через 2 недели, исправив указанные недочеты.",
                inline=False,
            )
            embed.set_thumbnail(url=REJECT_IMAGE)
            embed.set_footer(text="С уважением, администрация сервера", icon_url=LOGO_IMAGE)

            try:
                await member.send(embed=embed)
            except discord.Forbidden:
                print(f"Не удалось отправить ЛС пользователю {member}")

            await interaction.message.delete()
            await interaction.response.send_message("Заявка отклонена", ephemeral=True)
        except Exception as e:
            print(f"Ошибка: {e}")


class ApplicationModal(Modal):
    def __init__(self, role: str):
        super().__init__(title=f"Заявка на {role}", timeout=300)
        self.role = role
        for question, example in QUESTIONS[role]:
            self.add_item(
                TextInput(
                    label=question,
                    placeholder=example,
                    style=discord.TextStyle.short if len(question) < 50 else discord.TextStyle.long,
                    required=True,
                )
            )

    async def on_submit(self, interaction: discord.Interaction):
        try:
            answers = [item.value for item in self.children]
            embed = discord.Embed(
                title=f"Новая заявка: {self.role}",
                description=f"От {interaction.user.mention}",
                color=EMBED_COLOR,
            )
            for (question, _), answer in zip(QUESTIONS[self.role], answers):
                embed.add_field(name=question, value=answer or "Не указано", inline=False)

            channel = interaction.client.get_channel(APPLICATIONS_CHANNEL_ID)
            if channel:
                await channel.send(embed=embed, view=ApplicationView(interaction.user.id))
                await interaction.response.send_message(
                    "✅ Ваша заявка успешно отправлена!", ephemeral=True
                )
            else:
                await interaction.response.send_message(
                    "Ошибка: канал для заявок не найден", ephemeral=True
                )
        except Exception as e:
            print(f"Ошибка при отправке заявки: {e}")
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "Произошла ошибка при отправке заявки", ephemeral=True
                )


class LichessBot(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        async with aiosqlite.connect("lichess_bot.db") as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    discord_id INTEGER PRIMARY KEY,
                    lichess_username TEXT UNIQUE,
                    puzzles_solved INTEGER DEFAULT 0
                )
                """
            )
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS active_puzzles (
                    discord_id INTEGER PRIMARY KEY,
                    puzzle_id TEXT
                )
                """
            )
            await db.commit()

        self.add_view(PuzzleView(""))
        await self.tree.sync()
        print(f"Бот успешно запущен как {self.user}")

    async def on_ready(self):
        print(f"Бот {self.user} готов к работе!")
        try:
            channel = self.get_channel(MAIN_CHANNEL_ID)
            if not channel:
                print("Ошибка: основной канал не найден")
                return

            async for message in channel.history(limit=10):
                if message.author == self.user and message.components:
                    try:
                        await message.delete()
                    except Exception as e:
                        print(f"Ошибка при удалении сообщения: {e}")

            embed = discord.Embed(description=MAIN_EMBED_DESCRIPTION, color=EMBED_COLOR)

            select = Select(
                placeholder="Выберите нужное",
                options=[
                    discord.SelectOption(label="Moderator"),
                    discord.SelectOption(label="Editor"),
                    discord.SelectOption(label="Coach"),
                    discord.SelectOption(label="Support"),
                ],
            )

            async def select_callback(interaction: discord.Interaction):
                try:
                    role = interaction.data["values"][0]
                    modal = ApplicationModal(role)
                    await interaction.response.send_modal(modal)
                except Exception as e:
                    print(f"Ошибка в callback селектора: {e}")
                    if not interaction.response.is_done():
                        await interaction.response.send_message(
                            "Произошла ошибка при открытии формы", ephemeral=True
                        )

            select.callback = select_callback
            view = View(timeout=None)
            view.add_item(select)
            await channel.send(embed=embed, view=view)
        except Exception as e:
            print(f"Ошибка в on_ready: {e}")


client = LichessBot()

@client.tree.command(name="link", description="Начать процесс привязки Lichess аккаунта")
@app_commands.describe(username="Твой никнейм на Lichess")
async def link(interaction: discord.Interaction, username: str):
    async with aiosqlite.connect("lichess_bot.db") as db:
        async with db.execute(
            "SELECT lichess_username FROM users WHERE discord_id = ?",
            (interaction.user.id,),
        ) as cursor:
            existing_user = await cursor.fetchone()

    if existing_user:
        return await interaction.response.send_message(
            f"❌ Ты уже привязал аккаунт Lichess: **{existing_user[0]}**!\n"
            f"Повторная привязка не требуется.",
            ephemeral=True,
        )

    code = random.randint(100000, 999999)
    expiry = time.time() + 600
    verification_codes[interaction.user.id] = {
        "username": username,
        "code": str(code),
        "expiry": expiry,
    }

    await interaction.response.send_message(
        f"🔗 **Привязка аккаунта Lichess: `{username}`**\n\n"
        f"1. Скопируй этот код: `{code}`\n"
        f"2. Вставь его в поле **'О себе' (Bio)** на Lichess и сохрани.\n"
        f"3. Напиши команду: `/done {username}`\n\n"
        f"⏳ *Внимание: код действителен в течение **10 минут**, после чего сгорит!*",
        ephemeral=True,
    )


@client.tree.command(name="done", description="Завершить верификацию")
@app_commands.describe(username="Твой никнейм на Lichess")
async def done(interaction: discord.Interaction, username: str):
    data = verification_codes.get(interaction.user.id)
    if not data or data["username"] != username:
        return await interaction.response.send_message(
            "❌ Сначала запусти `/link [ник]`", ephemeral=True
        )
    if time.time() > data["expiry"]:
        return await interaction.response.send_message(
            "❌ Время кода истекло.", ephemeral=True
        )

    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://lichess.org/api/user/{username}") as resp:
            if resp.status != 200:
                return await interaction.response.send_message(
                    "❌ Профиль не найден.", ephemeral=True
                )
            user_data = await resp.json()

    if data["code"] in str(user_data):
        async with aiosqlite.connect("lichess_bot.db") as db:
            await db.execute(
                """
                INSERT OR REPLACE INTO users (discord_id, lichess_username, puzzles_solved)
                VALUES (?, ?, COALESCE((SELECT puzzles_solved FROM users WHERE discord_id = ?), 0))
                """,
                (interaction.user.id, username, interaction.user.id),
            )
            await db.commit()
        await interaction.response.send_message(
            f"✅ Аккаунт **{username}** успешно привязан!", ephemeral=False
        )
        del verification_codes[interaction.user.id]
    else:
        await interaction.response.send_message(
            "❌ Код не найден в Bio профиля.", ephemeral=True
        )


@client.tree.command(name="profile", description="Посмотреть свои рейтинги Lichess")
async def profile(interaction: discord.Interaction):
    row = await get_user_row(interaction.user.id)
    if not row:
        return await interaction.response.send_message(
            "❌ Сначала привяжи аккаунт через `/link`", ephemeral=True
        )

    username, puzzles_solved = row[0], row[1]

    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://lichess.org/api/user/{username}") as resp:
            if resp.status != 200:
                return await interaction.response.send_message(
                    "❌ Ошибка Lichess API.", ephemeral=True
                )
            data = await resp.json()

    perfs = data.get("perfs", {})
    blitz = perfs.get("blitz", {}).get("rating", "N/A")
    rapid = perfs.get("rapid", {}).get("rating", "N/A")
    bullet = perfs.get("bullet", {}).get("rating", "N/A")
    puzzle_rating = perfs.get("puzzle", {}).get("rating", "N/A")

    embed = discord.Embed(
        title=f"♟️ Профиль Lichess: {username}",
        url=data.get("url"),
        color=discord.Color.from_rgb(34, 34, 34),
    )
    embed.add_field(name="🔥 Bullet", value=str(bullet), inline=True)
    embed.add_field(name="⚡ Blitz", value=str(blitz), inline=True)
    embed.add_field(name="⏱️ Rapid", value=str(rapid), inline=True)
    embed.add_field(name="🧩 Рейтинг задач", value=str(puzzle_rating), inline=True)
    embed.add_field(name="🏆 Решено задач через бота", value=str(puzzles_solved), inline=True)

    if "profile" in data and "flag" in data["profile"]:
        embed.set_footer(text=f"Страна: {data['profile']['flag']}")

    await interaction.response.send_message(embed=embed)


async def puzzle_cmd_logic(interaction: discord.Interaction):
    is_button = interaction.data and "custom_id" in interaction.data
    await interaction.response.defer()

    user_id = interaction.user.id
    user_row = await get_user_row(user_id)
    if not user_row:
        return await interaction.followup.send(
            "❌ Сначала привяжи аккаунт Lichess через `/link <username>`!",
            ephemeral=True,
        )

    async with aiohttp.ClientSession() as session:
        result = await fetch_random_puzzle(session)
        if not result:
            return await interaction.followup.send(
                "❌ Не удалось получить задачу с Lichess. Попробуй чуть позже.",
                ephemeral=True,
            )
        puzzle_id, fen = result

    puzzle_url = f"https://lichess.org/training/{puzzle_id}"

    async with aiosqlite.connect("lichess_bot.db") as db:
        await db.execute(
            """
            INSERT INTO active_puzzles (discord_id, puzzle_id)
            VALUES (?, ?)
            ON CONFLICT(discord_id) DO UPDATE SET puzzle_id = EXCLUDED.puzzle_id
            """,
            (user_id, puzzle_id),
        )
        await db.commit()

    side = "black" if " b " in fen else "white"
    encoded_fen = urllib.parse.quote(fen)
    board_image_url = (
        f"https://lichess.org/export/fen.gif"
        f"?fen={encoded_fen}&color={side}&_t={int(time.time() * 1000)}"
    )

    embed = discord.Embed(
        title=f"🧩 Шахматная задача #{puzzle_id}",
        description="Перейди на сайт Lichess, реши позицию и нажми **«Засчитать задачу»**!",
        color=discord.Color.green(),
    )
    embed.set_image(url=board_image_url)
    embed.set_footer(text="Статистика и рейтинг обновляются в твоём профиле Lichess")

    view = PuzzleView(puzzle_url)

    if is_button and interaction.message:
        await interaction.message.edit(embed=embed, view=view)
    else:
        await interaction.followup.send(embed=embed, view=view)


@client.tree.command(name="puzzle", description="Получить случайную задачу")
async def puzzle_cmd(interaction: discord.Interaction):
    await puzzle_cmd_logic(interaction)


@client.tree.command(name="solved", description="Проверить и засчитать задачу")
async def solved_cmd(interaction: discord.Interaction):
    view = PuzzleView("")
    await view.solved_button.callback(interaction)


@client.tree.command(name="leaderboard", description="Таблица лидеров сервера")
async def leaderboard(interaction: discord.Interaction):
    async with aiosqlite.connect("lichess_bot.db") as db:
        async with db.execute(
            "SELECT lichess_username, puzzles_solved FROM users "
            "ORDER BY puzzles_solved DESC LIMIT 10"
        ) as cursor:
            rows = await cursor.fetchall()

    if not rows:
        return await interaction.response.send_message(
            "📊 На сервере пока нет привязанных пользователей.", ephemeral=True
        )

    desc = ""
    for idx, (uname, solved) in enumerate(rows, 1):
        medal = "🥇" if idx == 1 else "🥈" if idx == 2 else "🥉" if idx == 3 else f"`#{idx}`"
        desc += f"{medal} **{uname}** — {solved} решенных задач\n"

    embed = discord.Embed(title="🏆 Лидерборд сервера", description=desc, color=discord.Color.gold())
    await interaction.response.send_message(embed=embed)


@client.tree.command(name="challenge", description="Бросить вызов участнику")
@app_commands.describe(
    opponent="Кого вызываешь",
    time_control="Контроль (например: 5+3)",
    mode="Режим",
)
@app_commands.choices(
    mode=[
        app_commands.Choice(name="Rated (на рейтинг)", value="rated"),
        app_commands.Choice(name="Casual (без рейтинга)", value="casual"),
    ]
)
async def challenge(
    interaction: discord.Interaction,
    opponent: discord.Member,
    time_control: str,
    mode: str,
):
    if opponent.id == interaction.user.id:
        return await interaction.response.send_message(
            "❌ Нельзя бросить вызов самому себе!", ephemeral=True
        )

    async with aiosqlite.connect("lichess_bot.db") as db:
        async with db.execute(
            "SELECT discord_id, lichess_username FROM users WHERE discord_id IN (?, ?)",
            (interaction.user.id, opponent.id),
        ) as cursor:
            rows = await cursor.fetchall()

    users_map = {row[0]: row[1] for row in rows}
    if interaction.user.id not in users_map or opponent.id not in users_map:
        return await interaction.response.send_message(
            "❌ Ошибка: оба игрока должны привязать Lichess через `/link`!",
            ephemeral=True,
        )

    try:
        parts = time_control.replace(" ", "").split("+")
        minutes = int(parts[0])
        increment = int(parts[1]) if len(parts) > 1 else 0
    except Exception:
        return await interaction.response.send_message(
            "❌ Неверный формат контроля. Используй, например: `5+3` или `10+0`",
            ephemeral=True,
        )

    game_mode = "casual" if mode == "casual" else "rated"

    challenge_url = (
        f"https://lichess.org/?user={users_map[opponent.id]}"
        f"&time=realTime"
        f"&minutesPerSide={minutes}"
        f"&increment={increment}"
        f"&gameMode={game_mode}"
        f"#friend"
    )

    msg_text = (
        f"⚔️ **Вызов!** {interaction.user.mention} вызывает {opponent.mention} "
        f"({time_control} | {mode})\n"
        f"🔗 **[Принять вызов на Lichess]({challenge_url})**"
    )

    await interaction.response.send_message(msg_text)
    try:
        await opponent.send(f"Вас вызвали на дуэль!\n{msg_text}")
    except discord.Forbidden:
        pass


# вставь свой токен
client.run("MTUzNzUwNzk2OTAwMzAzNjg1Mw.Go54ot.BHa8FbBNJW5dJiutXSs_crIepVZ6QfHLIZDwso")
